# INF 286 HTML Bingo
INF 286 Assignment 09

## Team Members

**Ryan Gehling** - gehlingr1@nku.edu  /   index&superHeros
**Naeun Kim** - kimn5@nku.edu   /   README.md && art.html
**Alice Nguyen** - nguyena6@nku.edu   /    contact me && contact thanks
**Serenity Newell-Goodwin** - newellgoos1@nku.edu   /   work.html
**Stacey Sanchez Gomez** - sanchezgos1@nku.edu   /   puppies.html
**Mason Miller** - millerm106@nku.edu   /    music.txt
